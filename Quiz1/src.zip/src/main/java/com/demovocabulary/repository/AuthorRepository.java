package com.demovocabulary.repository;

public class AuthorRepository {
}
