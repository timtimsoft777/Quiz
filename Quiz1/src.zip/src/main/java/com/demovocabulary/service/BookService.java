package com.demovocabulary.service;

public class BookService {
}
