package com.demovocabulary.controller;

public class AuthorController {
}
