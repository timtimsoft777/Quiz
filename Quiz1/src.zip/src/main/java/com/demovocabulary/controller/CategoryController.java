package com.demovocabulary.controller;

public class CategoryController {
}
