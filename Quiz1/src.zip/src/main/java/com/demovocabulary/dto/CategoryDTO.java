package com.demovocabulary.dto;

public class CategoryDTO {
}
