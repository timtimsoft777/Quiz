package com.demovocabulary.mapper;

public class CategoryMapper {
}
