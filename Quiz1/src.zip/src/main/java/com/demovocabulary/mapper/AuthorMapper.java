package com.demovocabulary.mapper;

public class AuthorMapper {
}
