package com.demovocabulary.mapper;

public class BookMapper {
}
