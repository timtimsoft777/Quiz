package com.demovocabulary.repository;

public class CategoryRepository {
}
