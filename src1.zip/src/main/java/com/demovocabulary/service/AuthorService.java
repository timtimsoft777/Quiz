package com.demovocabulary.service;

public class AuthorService {
}
