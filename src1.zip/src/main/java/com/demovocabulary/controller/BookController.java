package com.demovocabulary.controller;

public class BookController {
}
